import time

from src.char.BaseChar import SwitchPriority
from src.char.Carlotta import Carlotta as NativeCarlotta
from src.char.ShoreKeeper import ShoreKeeper as NativeShoreKeeper
from src.char.Zhezhi import Zhezhi as NativeZhezhi


class ShoreKeeper(NativeShoreKeeper):
    """守岸人 —— 珂折守（珂莱塔 / 折枝 / 守岸人）25 秒矩阵低充无缝轴里的这一棒。

    轴出处: 用户提供的视频文字轴（首轮 / 循环），见 ../media/info.md、
    ../skilltest-v1/timeline.json。三个文件的公共段由 _build.py 统一生成。
    """

    TAG = 'shorekeeper'

    # ================================================================ 公共段（三个文件逐字一致，改一处记得同步改三处）
    #
    # 为什么不用框架的 switch_next_char():
    #   1. 它按 get_switch_priority() 现场挑人, 顺序会漂 —— 这套轴是死顺序;
    #   2. 它内部有三处补普攻 (performing too fast / 维持锁定 / 切人没认到时补点击),
    #      打完最后一下想立刻走人时那几下 A 会把节奏拖乱;
    #   3. 守岸人满协奏下场后 16 秒内会被框架判成 NO, 而这一圈里她两次上场只隔 4 个节点
    #      —— 直接按数字键切人绕开了这条锁。
    # 代价是框架的交接记账要自己补, 全在 handoff_to() 里。
    SWITCH_TIMEOUT: float = 2.0        # 单程切人的最长尝试时间 (秒)
    SWITCH_KEY_INTERVAL: float = 0.12  # 连按数字键的间隔 (秒)
    SWITCH_SETTLE: float = 0.06        # 切到之后等角色站稳 (秒); 19:50 再压一档
    HANDOFF_CON_WAIT: float = 0.8      # 补刀后等协奏读数稳定的上限 (秒)
    HANDOFF_CON_POLL: float = 0.1
    CON_QUICK_WAIT: float = 0.08       # 平切前的读数确认; 不为「可能刚好满」空等 0.8s
    CON_CONFIRM_WAIT: float = 0.12     # 满协奏要连读两次: 0.99/1.04 那种读数会抖
    HOLD_POLL: float = 0.1
    FILL_CON_INTERVAL: float = 0.20
    TEAM_HUD_WAIT: float = 3.0         # 大招/击破演出期间队伍 HUD 整块不画, 盲区最多等这么久
    SWITCH_ANCHOR_MAX: float = 1.5
    INTRO_PENDING_TTL: float = 8.0
    LEAVE_TRIES: int = 2
    GATE_LOG_EVERY: float = 3.0
    # 本角色作为「开场自然入场」时跑哪个节点。默认 f1；守岸人改成 f0（只交接，不出手）
    OPENER_MODE: str = 'f1'
    # 首动作是「轮询等提示」的节点, 入场不用睡满 INTRO_ANIM, 提前轮询即可
    FAST_INTRO_MODES: tuple = ()
    FAST_INTRO_ANIM: float = 0.40

    # ---- 交接状态（写成类属性: CharFactory 换类时只覆盖「内置实例也有」的字段）
    # 别人用 handoff_to() 交给我时打的标记。不能只靠 has_intro —— reset_state() 每次
    # 重读队伍都会把它清成 False, 而战斗判定一抖动就会重进战斗、重读队伍。
    intro_pending = False
    intro_pending_at = 0.0
    # 切人【真正完成】那一刻 (in_team 认出换人成功的那一帧), 作用是给下一个角色的
    # 入场等待当锚点 —— 差 0.55 秒就会掉进「入场动作没演完就按键」的失败区
    switch_confirmed_at = 0.0
    # 上一棒是谁交过来的
    handoff_source = None
    handoff_source_at = 0.0
    # 本次离场许可的补协奏时长 (秒)。由动作体在最后一句话之前写, 默认不补
    _exit_fill = 0.0
    # 本节点刚确认过协奏满（例如 E 连段提前收手），离场时不必再读一遍
    _con_full_confirmed = False
    # 平切边: 不需要协奏确认, 动作一结束就按切人键 (省 0.15-0.3s/次)
    _skip_con_check = False
    # 强切协议
    _force_switch_me = False
    _entry_mode = None
    _node = None
    started = False
    _startup_done = False
    _axis_char = True

    def note_handoff_source(self, source):
        """被 handoff_to() 交接进场时调用 —— 记下上一棒是谁。带不带变奏都记。"""
        self.handoff_source = source.__class__.__name__ if source is not None else None
        self.handoff_source_at = time.time()

    def take_handoff_source(self):
        """读出上一棒是谁, 读完就清。过期的不认。"""
        name = self.handoff_source
        if name is not None and time.time() - self.handoff_source_at > self.INTRO_PENDING_TTL:
            self.logger.info(f'{self.TAG}: handoff_source ({name}) 已过期, 按未知处理')
            name = None
        self.handoff_source = None
        self.handoff_source_at = 0.0
        return name

    def note_intro_handoff(self):
        """被别人用直接切人的方式交接进场时调用 —— 记下「我是带着变奏上来的」。"""
        self.intro_pending = True
        self.intro_pending_at = time.time()

    def take_intro(self):
        """本次入场是否带着变奏。读完就清, 避免下一轮误判。

        过期的标记不认: 手动停任务时 combat_end() 整个被跳过, 标记会留在角色身上,
        而 reset_state() 又【故意】不清它 (战斗判定一抖动就会重读队伍)。
        """
        pending = self.intro_pending
        if pending and time.time() - self.intro_pending_at > self.INTRO_PENDING_TTL:
            self.logger.info(f'{self.TAG}: intro_pending 已过期, 按空手入场处理')
            pending = False
        self.intro_pending = False
        self.intro_pending_at = 0.0
        return self.has_intro or pending

    def reset_fixed_rotation(self, chars=None):
        """战斗结束时清全队的交接标记 (combat_end 只对当前角色调 on_combat_end)。"""
        for char in (chars if chars is not None else [self]):
            if char is None:
                continue
            char.intro_pending = False
            char.intro_pending_at = 0.0
            char.handoff_source = None
            char.handoff_source_at = 0.0

    # ---------------------------------------------------------------- 切人
    def switch_to_index(self, index):
        """按数字键切到指定队伍位置, 直到 in_team 确认切过去了。

        【HUD 看不见时不要连按、也不要吃满超时】大招收尾和击破演出期间整块队伍 HUD
        不渲染, in_team 只回 False。盲区里补按一次就等着, 单独受 TEAM_HUD_WAIT 约束,
        看见 HUD 再核对 index —— 否则会白按满 SWITCH_TIMEOUT 然后判失败。
        """
        start = time.time()
        blind_total = 0.0
        blind_pressed = False
        while True:
            in_team, current_index, _ = self.task.in_team()
            if in_team:
                blind_pressed = False
                if current_index == index:
                    # 【先记时间戳再站稳】: settle 要花 SWITCH_SETTLE 秒, 记在它后面
                    # 锚点就整体晚 0.55 秒, 靠锚点计的入场等待全跟着晚
                    self.switch_confirmed_at = time.time()
                    self.settle_after_switch(self.SWITCH_SETTLE)
                    return True
                if time.time() - start - blind_total >= self.SWITCH_TIMEOUT:
                    return False
                self.task.send_key(index + 1)
            else:
                blind_total += self.SWITCH_KEY_INTERVAL
                if blind_total >= self.TEAM_HUD_WAIT:
                    return False
                if not blind_pressed:
                    self.task.send_key(index + 1)
                    blind_pressed = True
            self.task.next_frame()
            self.sleep(self.SWITCH_KEY_INTERVAL, check_combat=False)

    def settle_after_switch(self, duration):
        """切人确认之后等角色站稳。

        【这里不点普攻】: 这一套每个节点的起手动作都要数得清 (守岸人 3a、折枝 3a),
        切人期间多点的 A 会被算进连段里, 让段数漂掉。
        """
        self.sleep(max(0.0, duration), check_combat=False)

    def handoff_to(self, target, has_intro):
        """把场上角色交接给 target —— 复刻 switch_next_char() 内部那套记账。

        直接按数字键切人绕开了框架的交接逻辑, 必须自己补上, 否则:
          - 没人的 is_current_char 是 True → get_current_char() 返回 None → 下一帧崩溃;
          - has_intro / last_outro_time 不更新, 下一个角色拿不到变奏。
        """
        self.task.in_liberation = False
        self.switch_out(con_full=has_intro)
        target.is_current_char = True
        target.has_intro = has_intro
        if hasattr(target, 'note_handoff_source'):
            target.note_handoff_source(self)
        if has_intro and hasattr(target, 'note_intro_handoff'):
            target.note_intro_handoff()
        target.last_switch_in_time = self.switch_confirmed_at or time.time()
        self.switch_confirmed_at = 0.0
        if has_intro:
            now = time.time()
            self.task.add_freeze_duration(now, target.intro_motion_freeze_duration, -100)
            self.last_outro_time = now

    def wait_con_full(self, timeout=None):
        """短暂轮询协奏是否满 —— 决定交接时给不给对方变奏。

        不能只读一次: 打完最后一下那一刻协奏其实已经满了, 但能量环读数滞后;
        19:16 的日志里还出现过 1.00–1.04 被夹成 0.99、is_con_full 时真时假的抖动,
        单次读满就切会把「没满」当成「满了」(珂莱塔因此没吃到延奏)。所以满要
        连读两次 (间隔 CON_CONFIRM_WAIT)。
        平切只等 CON_QUICK_WAIT; 补刀后才用 HANDOFF_CON_WAIT 的长上限。
        """
        timeout = self.HANDOFF_CON_WAIT if timeout is None else timeout
        start = time.time()
        while time.time() - start < timeout:
            if self.is_con_full():
                self.sleep(self.CON_CONFIRM_WAIT, check_combat=False)
                if self.is_con_full():
                    return True
            else:
                self.sleep(self.HANDOFF_CON_POLL, check_combat=False)
        return False

    def char_at_slot(self, slot):
        """按队伍位置 (1-based) 取角色, 越界返回 None。"""
        index = slot - 1
        for char in self.task.chars:
            if char is not None and char.index == index:
                return char
        return None

    def wait_team_hud(self, timeout=None):
        """等右侧队伍头像渲染回来 —— 演出期间它整块是不画的。"""
        timeout = self.TEAM_HUD_WAIT if timeout is None else timeout
        start = time.time()
        while time.time() - start < timeout:
            if self.task.in_team()[0]:
                return True
            self.task.next_frame()
            self.sleep(0.08, check_combat=False)
        self.logger.warning(f'{self.TAG}: 队伍 HUD {timeout:.1f}s 还没回来')
        return False

    def switch_in_anchor(self):
        """本轮的计时基准: 头像认出「切人完成」的那一刻, 不是 do_perform 被调那一刻。"""
        now = time.time()
        anchored = self.last_switch_in_time
        gap = now - anchored if anchored > 0 else -1
        if 0 <= gap <= self.SWITCH_ANCHOR_MAX:
            return anchored
        return now

    # ---------------------------------------------------------------- 强切协议
    def get_switch_priority(self, current_char=None, has_intro=False, target_low_con=False):
        """只给框架兜底路径用: 被标记的人 MUST, 其他人 NO, 否则 NORMAL。

        【不再单独判 healer_full_con_switch_locked】: 框架的 _choose_switch_target 在
        调用本函数之前就先把满协奏锁定期的治疗判成 NO 了, 这里再判一次只会让兜底
        路径彻底没有人可切。
        """
        if self._force_switch_me:
            return SwitchPriority.MUST
        for char in self.task.chars:
            if char is not None and char is not self and getattr(char, '_force_switch_me', False):
                return SwitchPriority.NO
        return SwitchPriority.NORMAL

    def _find_teammate(self, class_name):
        """按类名找队友 —— 工坊类各自独立加载, isinstance 对 src.char.* 不成立。"""
        for char in self.task.chars:
            if char is not None and char.__class__.__name__ == class_name:
                return char
        return None

    def _mark_startup_done(self):
        for char in self.task.chars:
            if char is not None:
                char._startup_done = True

    def _exit_intro(self):
        """离场前定「下一个人带不带变奏」。必须先读协奏, 再按切人键。

        【平切不再空等】v3.1.1 每次离场都等 0.8s「可能刚好满」, 一局 6 次平切
        就多花 4.8s; 现在平切只做 CON_QUICK_WAIT 的短确认。
        """
        if self._skip_con_check:
            self._skip_con_check = False
            self._exit_fill = 0.0
            return False
        fill = self._exit_fill
        self._exit_fill = 0.0
        if self._con_full_confirmed:
            self._con_full_confirmed = False
            return True
        if fill <= 0:
            return self.wait_con_full(self.CON_QUICK_WAIT)
        if self.wait_con_full(self.CON_QUICK_WAIT):
            return True
        self.logger.info(f'{self.TAG}: 协奏没满, 离场前补普攻 (上限 {fill:.1f}s)')
        start = time.time()
        filled_full = False
        while self.time_elapsed_accounting_for_freeze(start) < fill:
            if self.is_con_full():
                # 连读两次才算满: 0.99 的抖动会让延奏交不出去
                self.sleep(self.CON_CONFIRM_WAIT, check_combat=False)
                if self.is_con_full():
                    filled_full = True
                    break
            self.check_combat()
            self.click()
            self.sleep(self.FILL_CON_INTERVAL)
        has_intro = filled_full or self.wait_con_full(self.CON_QUICK_WAIT)
        if not has_intro:
            self.logger.info(f'{self.TAG}: 交接时协奏没满, 下一个人按平切入场')
        return has_intro

    def _direct_switch(self, target, has_intro):
        """按数字键直接切过去 + 自己补交接记账。失败返回 False 交给框架兜底。"""
        for attempt in range(1, self.LEAVE_TRIES + 1):
            self.wait_team_hud()
            if self.switch_to_index(target.index):
                self.handoff_to(target, has_intro)
                self.logger.info(f'{self.TAG}: 交接 {target.__class__.__name__} '
                                 f'(intro={has_intro}, 第 {attempt} 次)')
                return True
            # 切不过去时再读一次: 补的普攻可能刚把协奏打满
            has_intro = has_intro or self.wait_con_full()
            self.logger.warning(f'{self.TAG}: 直切失败 (第 {attempt}/{self.LEAVE_TRIES} 次)')
        return False

    def _force_switch_to(self, target, mode):
        """把棒交给 target 并让它跑 perform_<mode>。"""
        if target is None:
            self.logger.warning(f'{self.TAG}: fallback: framework_switch reason=teammate_missing')
            return self.switch_next_char()
        target._entry_mode = mode
        for char in self.task.chars:
            if char is not None:
                char._force_switch_me = char is target
        try:
            has_intro = self._exit_intro()
            if self._direct_switch(target, has_intro):
                return True
            self.logger.warning(f'{self.TAG}: fallback: framework_switch reason=direct_switch_failed')
            return self.switch_next_char()
        finally:
            for char in self.task.chars:
                if char is not None:
                    char._force_switch_me = False

    # ---------------------------------------------------------------- 分发器
    def do_perform(self):
        mode = self._entry_mode
        self._entry_mode = None
        entry = 'natural' if mode is None else 'forced'
        if mode is None:
            if not self.started:
                mode = self.OPENER_MODE
            elif self._startup_done:
                mode = 's1'
            else:
                self.logger.info(f'{self.TAG}: 启动轴进行中被自然入场, 交还框架切人')
                return self.switch_next_char()
        if mode.startswith('s'):
            self._mark_startup_done()
        self.started = True
        func = getattr(self, 'perform_' + mode, None)
        if func is None:
            self.logger.info(f'{self.TAG}: interrupt reason=unknown_mode mode={mode} next=framework')
            return self.switch_next_char()
        self._node = mode
        self.check_f_on_switch = False
        source = self.take_handoff_source()
        intro = self.take_intro()
        anchor = self.switch_in_anchor()
        self.logger.info(f'{self.TAG}: [{mode.upper()}] enter (intro={intro}, '
                         f'mode={entry}, source={source})')
        if intro:
            # 用【切人确认那一刻】当基准: 中间隔着交接记账和任务循环, 那段延迟是变长的
            intro_anim = self.INTRO_ANIM
            if mode in getattr(self, 'FAST_INTRO_MODES', ()):
                # 首动作是 forte_heavy 这类轮询, 早按的键会被 QTE 忽略, 不会打乱节奏
                intro_anim = self.FAST_INTRO_ANIM
            self.sleep(max(0.0, anchor + intro_anim - time.time()), check_combat=False)
        if self.flying():
            # wait_down 会空耗 2.5s, 而且 flying() 在地面也会误判; 只给短落地
            self.sleep(0.30, check_combat=False)
            self.click()
            self.sleep(0.20, check_combat=False)
        return func()

    def reset_state(self):
        super().reset_state()
        self.started = False
        self._startup_done = False
        self._entry_mode = None
        self._exit_fill = 0.0
        self._con_full_confirmed = False
        self._skip_con_check = False
        self._reset_char_state()

    def on_combat_end(self, chars):
        self.reset_fixed_rotation(chars)
        super().on_combat_end(chars)

    # ---------------------------------------------------------------- 通用动作
    def attack_chain(self, count, interval, last_interval=None):
        """点按普攻打一轮连段。last_interval 给最后一段之后的间隔。"""
        for i in range(count):
            self.click()
            if i == count - 1 and last_interval is not None:
                self.sleep(last_interval)
            else:
                self.sleep(interval)

    def _action_handoff(self, tag, nxt):
        """只交接、不出手的节点用: 清掉补刀许可并打一条 exit。"""
        self._exit_fill = 0.0
        self.logger.info(f'{self.TAG}: [{tag.upper()}] exit: ok reason=opener_handoff next={nxt}')

    def dodge(self):
        """闪避 = 右键。注意 "Dodge Key" 配置项是疾跑键, 不是战斗闪避。"""
        self.task.click(key='right')

    def forte_heavy(self, dodge=False):
        """强化重击: 等「满能量长按提示」亮起再按住, 按住直到提示消失。

        判据用找图(is_mouse_forte_full)而不是颜色百分比 —— 找图对特效糊屏更扛得住。
        提示还没亮就继续点普攻等: 普攻本身也在攒能量, 属于边等边攒。
        等到 FORTE_WAIT 还没亮就跳过 —— 这一步做不到不会传染给下一棒, 卡死在这里会。
        """
        start = time.time()
        ready = False
        while self.time_elapsed_accounting_for_freeze(start) < self.FORTE_WAIT:
            if self.is_mouse_forte_full():
                ready = True
                break
            self.check_combat()
            self.click()
            self.sleep(self.FORTE_FILL_INTERVAL)
        if not ready:
            self.logger.warning(f'{self.TAG}: 强化重击提示 {self.FORTE_WAIT:.1f}s 内没亮, 跳过')
            return False
        ok = bool(self.heavy_click_forte(self.is_mouse_forte_full))
        waited = self.time_elapsed_accounting_for_freeze(start)
        if ok and dodge:
            # 【重击 -> 马上闪 -> 马上普攻】: 闪避取消重击后摇, 紧接着的普攻再取消闪避后摇,
            # 中间不能留固定延时, 留了就两个都取消不掉
            self.dodge()
            self.click()
        self.logger.info(f'{self.TAG}: 强化重击 {"打出" if ok else "没打出"} (等 {waited:.2f}s)')
        return ok

    def fire_liberation(self, window=None):
        """R 大招 —— 在窗口里等图标亮了再按, 不是问一次就走。

        click_liberation() 只在「图标当下就亮着」时才真发键; 刚放完前一个动作时
        能量环那几帧最不可信。顺手清 task.in_liberation: 被上一个角色留成 True 的话,
        click_liberation() 开头那段发键会被整段跳过。
        click_f=False: 演出期间框架默认每 0.1 秒发一次 F, 这条轴上没有要她按的处决。
        """
        self.task.in_liberation = False
        window = self.LIB_WINDOW if window is None else window
        start = time.time()
        while self.time_elapsed_accounting_for_freeze(start) < window:
            self.task.next_frame()
            if self.liberation_available():
                waited = self.time_elapsed_accounting_for_freeze(start)
                if self.click_liberation(wait_if_cd_ready=0.3, click_f=False):
                    self.logger.info(f'{self.TAG}: 大招放出 (等了 {waited:.2f}s)')
                    return True
            self.check_combat()
            self.click()
            self.sleep(self.LIB_RETRY)
        self.logger.warning(f'{self.TAG}: 大招图标 {window:.1f}s 内没亮, 硬按一次')
        return bool(self.click_liberation(wait_if_cd_ready=0.5, click_f=False))

    def fire_echo(self):
        """Q 声骸 —— 连发, 不是只发一次。

        演出期间的按键被游戏丢弃、不排队, 只发一次很容易整段被吃掉; Q 是脱手技能,
        多按几下不会打断当前动作。先发键, 读屏只用来决定要不要重发。
        """
        if self.ECHO_TRIES <= 0:
            return False
        was_available = self.echo_available()
        if not was_available:
            self.logger.info(f'{self.TAG}: echo reads on-cd, sending once anyway')
        for i in range(self.ECHO_TRIES):
            self.send_echo_key()
            self.record_echo_use()
            self.sleep(self.ECHO_RETRY, check_combat=False)
            if not was_available:
                return False
            if not self.echo_available():
                if i:
                    self.logger.info(f'{self.TAG}: echo landed on try {i + 1}')
                return True
        self.logger.warning(f'{self.TAG}: echo still reads available after {self.ECHO_TRIES} tries')
        return False

    # ================================================================ 守岸人这一棒
    #
    # 轴原文: 首轮「守 3ae」→「守 3a-Z闪-3a-Z-qR」; 循环「守 3ae-2a-Z」→「守 3a-Z-qR」。
    #
    # 【Z 必须在 R 之前】: 视频 52~54 秒作者自己打了红字标注「此处有失误: 守回路必须
    # 打出去后R」。回路(核心)满 5 层时按住普攻放出的核心被动会把场上的茧全催成蝶,
    # 蝴蝶命中才给协奏; 先 R 的话这些协奏就吃不到, 后面的延奏交不出去。
    #
    # 【她两次上场之间只隔 4 个节点】: 所以这里必须走按数字键的直切, 框架那条
    # 「满协奏下场 16 秒内不许切回来」的锁会正好卡住她第二次上场。
    #
    # 【开场她在场上时不能直接 3ae】: 轴的首轮第一棒是折枝 q(闪)R-3a, 不是守岸人。
    # 实测 2026-11-21 的三局都是从她开场, 前面漏掉折 f1 后整条轴错位一格。所以
    # 自然入场走 f0(只交接), f1(3ae) 只在被明确交接过来时才跑。
    OPENER_MODE = 'f0'
    INTRO_ANIM = 1.45        # QTE: 第 86F 前不响应输入、第 65F 前不能切人
    A_INTERVAL = 0.32
    A_TO_E = 0.12
    E_TO_A = 0.55            # E-地面 派生 40F, 演完才轮得到下一组普攻
    A_TO_HEAVY = 0.15
    GROUP1_A = 3             # 轴里的「3a」
    GROUP2_A = 2             # 轴里的「2a」
    HEAVY_TO_ECHO = 0.12
    ECHO_TO_LIB = 0.04
    FORTE_WAIT = 5.0         # 等核心满(长按提示)的上限, 期间继续补普攻
    FORTE_FILL_INTERVAL = 0.20
    E_CAST_TIMEOUT = 0.9
    E_RETRIES = 2
    ECHO_TRIES = 1
    ECHO_RETRY = 0.05
    LIB_WINDOW = 4.0
    LIB_RETRY = 0.15

    def _reset_char_state(self):
        # 她登记的是 HEALER, BaseChar.__init__ 里 check_f_on_switch 已经是 False。
        # 再写一遍是防上游改默认值 —— 这条轴上没有要她按的处决
        self.check_f_on_switch = False
        # 原生 ShoreKeeper.switch_next_char() 里那两个记账字段: 队友的
        # shorekeeper_auto_dodge() 靠它们决定还能不能替人闪避。这里不走原生切人,
        # 所以自己维护 (见 _finish_qr)
        self.outrotime = -1
        self.dodge_count = 0

    def skip_combat_check(self):
        """大招演出期间照样算在战斗里: 她的大招有 3 秒以上全屏动画, HUD 全隐。"""
        return self.has_intro or self.flying()

    def switch_out(self, con_full=False):
        """满协奏离场时给全队开「替他闪避」窗口。

        原生 ShoreKeeper.switch_next_char() 里本来就有一段这个记账, 但本队走的是
        按数字键的直切, 绕开它了, 所以在 switch_out 这一层补上 —— 而 switch_out
        正好由 handoff_to() 带着 con_full 调, 拿到的就是「到底满没满」。
        """
        if con_full:
            self.outrotime = time.time()
            self.dodge_count = 5
        super().switch_out(con_full=con_full)

    # ------------------------------------------------------------------ 节点
    def perform_f0(self):
        """开场就在场上时只做交接: 轴的第一棒是折枝, 她按完 q(闪)R-3a 才轮到守 3ae。"""
        self._action_handoff('f0', 'Zhezhi.f1')
        self._force_switch_to(self._find_teammate('Zhezhi'), 'f1')

    def perform_f1(self):
        self._action_3ae('f1', 'Zhezhi.f2')
        self._force_switch_to(self._find_teammate('Zhezhi'), 'f2')

    def perform_f2(self):
        self._action_zigzag('f2', 'Carlotta.f2')
        self._force_switch_to(self._find_teammate('Carlotta'), 'f2')

    def perform_s1(self):
        self._action_3ae_2a_z('s1', 'Zhezhi.s2')
        self._force_switch_to(self._find_teammate('Zhezhi'), 's2')

    def perform_s2(self):
        self._action_3a_z_qr('s2', 'Carlotta.s1')
        self._force_switch_to(self._find_teammate('Carlotta'), 's1')

    # ------------------------------------------------------------------ 动作体
    def _action_3ae(self, tag, nxt):
        """3ae: 3 段普攻铺茧 + 攒核心, E 出来奶一口、撒 5 只蝴蝶 (协奏 +20/+10)。"""
        self.attack_chain(self.GROUP1_A, self.A_INTERVAL, last_interval=self.A_TO_E)
        ok = self.cast_resonance()
        self._skip_con_check = True
        self._exit_fill = 0.0
        self.logger.info(f'{self.TAG}: [{tag.upper()}] exit: ok={ok} reason=done next={nxt}')

    def _action_3ae_2a_z(self, tag, nxt):
        """3ae-2a-Z: 3a -> E -> 2a -> 回路重击(核心被动, 把茧全催成蝶)。"""
        self.attack_chain(self.GROUP1_A, self.A_INTERVAL, last_interval=self.A_TO_E)
        ok = self.cast_resonance()
        self.sleep(self.E_TO_A)
        self.attack_chain(self.GROUP2_A, self.A_INTERVAL, last_interval=self.A_TO_HEAVY)
        heavy = self.forte_heavy()
        self._skip_con_check = True
        self._exit_fill = 0.0
        self.logger.info(f'{self.TAG}: [{tag.upper()}] exit: ok={ok and heavy} '
                         f'reason=done next={nxt}')

    def _action_zigzag(self, tag, nxt):
        """3a-Z闪-3a-Z-qR: 两组「3a + 回路重击」, 第一组后面闪一下断后摇, 最后 Q + R。"""
        self.attack_chain(self.GROUP1_A, self.A_INTERVAL, last_interval=self.A_TO_HEAVY)
        self.forte_heavy(dodge=True)
        # 第一次 Z 后的闪避会把后摇带在空中; 第二组 3a 前先落一下地,
        # 否则普攻打不到核心, 第二次 Z 要等 2s+ (19:36/19:50 实测 2.0–2.1s)
        self.sleep(0.20, check_combat=False)
        self.click()
        self.sleep(0.25, check_combat=False)
        # 第二组打 5a: 3a 只给 4 层核心, 第二段 Z 要等 1.6–2.1s;
        # 多打两下 A 换掉那段空等 (用户要求压时间)
        self.attack_chain(self.GROUP1_A + 2, self.A_INTERVAL, last_interval=self.A_TO_HEAVY)
        self.forte_heavy()
        self._finish_qr(tag, nxt)

    def _action_3a_z_qr(self, tag, nxt):
        """3a-Z-qR: 循环那一棒, 少打一组。"""
        self.attack_chain(self.GROUP1_A, self.A_INTERVAL, last_interval=self.A_TO_HEAVY)
        self.forte_heavy()
        self._finish_qr(tag, nxt)

    def _finish_qr(self, tag, nxt):
        """Q -> R 收工。R 之后这一段是「延珂」: 没满就补最多 1.0 秒普攻再走。"""
        self.sleep(self.HEAVY_TO_ECHO)
        self.fire_echo()
        self.sleep(self.ECHO_TO_LIB)
        ok = self.fire_liberation()
        if ok:
            # R 打完协奏必满 (日志 switch_out 每次都是 full con), 离场不再重读
            self._con_full_confirmed = True
        # 满协奏离场的记账在 switch_out() 里 (见那里的注释)
        self._exit_fill = 1.5
        self.logger.info(f'{self.TAG}: [{tag.upper()}] exit: ok={ok} reason=done next={nxt}')

    # ------------------------------------------------------------------ 动作
    def cast_resonance(self):
        """E —— 发键后确认它真的进了冷却; 被受击打断就补一下普攻再重发。

        【不用 click_resonance】: 它内部按白色像素决定发不发键, 特效糊屏时会一路
        空转到超时; 这里要的只是「按下去了、真进冷却了」。
        """
        for attempt in range(self.E_RETRIES):
            self.check_combat()
            self.send_resonance_key()
            if self.task.wait_until(lambda: not self.resonance_available(),
                                    time_out=self.E_CAST_TIMEOUT):
                self.record_resonance_use()
                return True
            if attempt + 1 < self.E_RETRIES:
                self.logger.warning(f'{self.TAG}: E 第 {attempt + 1} 次没生效, 补普攻后重发')
                self.click()
                self.sleep(0.25)
        self.logger.warning(f'{self.TAG}: E 两次都没进冷却, 跳过')
        return False
